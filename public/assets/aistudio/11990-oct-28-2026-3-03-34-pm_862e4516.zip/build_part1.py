# -*- coding: utf-8 -*-
import json

part1 = [
    {
        "id": "ln-c1",
        "chapterNumber": 1,
        "title": "Chương 1: Cuộc Hẹn Ở Đường Kim Ngạn",
        "wordCount": 3250,
        "views": 142000,
        "publishedAt": "2025-01-10",
        "isExtra": False,
        "content": """8h40 tối.

Sau khi kết thúc cuộc họp cuối cùng trong ngày, Tô Chấp Duật mới bước ra khỏi công ty.

Vừa ra khỏi cổng công ty, điện thoại trong túi áo vest của hắn lại bắt đầu rung lên như đã đoán chắc được giờ giấc làm việc của hắn. Tô Chấp Duật lấy điện thoại ra, thấy trong điện thoại đã có hai cuộc gọi nhỡ đều là của Trình Thi Duyệt.

Từ lần gặp gỡ không mấy vui vẻ vào tuần trước hai người đã không còn liên hệ với nhau, không ngờ lúc này Trình Thi Duyệt lại đến tìm hắn nữa.

Hắn trượt mở màn hình điện thoại, bấm vào tin nhắn của đối phương.

“Ngài Tô, em xin lỗi vì chuyện lần trước, hy vọng ngài không trách em. Em muốn hẹn gặp mặt ngài để giải thích chút chuyện, biết ngài bận nên em đã đặt chỗ trước tại nhà hàng trên đường Kim Ngạn, em sẽ đợi đến mười hai giờ….”

Tô Chấp Duật quen biết Trình Thi Duyệt tại một buổi tiệc chiêu đãi do Tô Nghiệp Đường tổ chức cách đây không lâu.

Cô ta là một người phụ nữ trưởng thành thông minh, quyến rũ với mái tóc xoăn dày.

Lần gặp mặt đầu tiên, cô ta cũng thể hiện mình là tay già đời trong những bữa tiệc. Chiếc váy đuôi cá màu đen ôm lấy những đường cong cơ thể nổi bật, sau khi buổi chiêu đãi bắt đầu cô ta bước về phía Tô Chấp Duật với ly rượu vang đỏ trên tay nhiệt tình bắt chuyện với hắn.

Kể từ khi hắn đảm nhận vị trí giám đốc của tập đoàn Công nghệ Tô Đức, những người bên cạnh muốn lấy lòng hắn cũng không ít. Nhưng hắn chỉ lo tập trung vào công việc, gặp mấy chuyện thế này chỉ cảm thấy rất phiền phức.

Đúng lúc này hắn gặp được Trình Thi Duyệt, lý do chính khiến hắn sẵn sàng cho cô ta cơ hội là vì cô ta sở hữu ngoại hình nổi bật, cách cư xử khéo léo không bao giờ đi quá giới hạn hay bám người quá mức, lúc nào cũng nở nụ cười rạng rỡ và thể hiện bản thân xuất sắc trong mọi tình huống.

Nếu đã có Trình Thi Duyệt bên cạnh, những vấn đề rắc rối khác cũng tự nhiên được giải quyết vô cùng sạch sẽ.

Tô Chấp Duật điều tra lý lịch của Trình Thi Duyệt ngay khi cho phép cô ta ở bên cạnh mình, phát hiện cô ta tốt nghiệp một trường đại học danh tiếng, bởi vậy cử chỉ và cách ăn nói cũng hoàn toàn khác với những người phụ nữ được mấy tên doanh nhân sắp xếp để trèo lên giường hắn trước đây.

Nói chung hắn hài lòng với Trình Thi Duyệt. Cô ta là một người phụ nữ thông minh, có EQ cao nên cũng có thể mang lại một chút giá trị tinh thần nào đó. Mỗi khi Tô Chấp Duật đưa cô ta đi xem vài buổi triển lãm tranh hay nghe các buổi biểu diễn âm nhạc, cũng nghe cô ta chia sẻ một số suy ngẫm và hiểu biết độc đáo của mình.

Trong gần ba tháng hai người duy trì mối quan hệ, Tô Chấp Duật hào phóng tặng cho cô ta không ít túi xách và trang sức hàng hiệu. Nếu không có gì bất ngờ xảy ra, mối quan hệ khiến hai bên đều hài lòng này sẽ kéo dài lâu hơn.

Nhưng đúng ngay lúc này Trình Thi Duyệt lại nóng vội, làm một chuyện khiến hắn cảm thấy bị xúc phạm.

Sau khi hai người uống chút rượu trong bữa tối, cô ta vô tình làm đổ đĩa ăn khiến quần áo bị bẩn. Tô Chấp Duật vẫn ra vẻ lịch sự, cùng cô ta đến dãy phòng khách sạn phía trên nhà hàng để thay quần áo.

Lúc ấy đã gần sáng sớm, Tô Chấp Duật nghe thấy tiếng Trình Thi Duyệt đang tắm trong phòng tắm không khỏi cảm thấy có gì đó không ổn, lúc này hắn đứng dậy vặn tay nắm cửa lại phát hiện cửa phòng đã bị khóa.

Sau đó, tiếng nước trong phòng tắm cũng ngừng lại. Trình Thi Duyệt từ phòng tắm đi ra chỉ mặc một chiếc áo choàng tắm, toàn thân ướt át đi chân trần ra ngoài…

Thủ đoạn thế này chẳng được tính là cao siêu, bọn họ đều đã quen biết nhau được gần ba tháng nhưng quan hệ vẫn cứ lấp lửng tại chỗ, bây giờ Trình Thi Duyệt muốn làm liều một lần cũng không có gì lạ.

Chuyện nam nữ vốn dĩ rất bình thường.

Nhưng điều khác thường là Tô Chấp Duật chẳng có phản ứng gì trước sự cám dỗ.

Hắn rõ ràng không thích kiểu chủ động này, người đàn ông từ trước đến nay luôn tỏ ra dịu dàng trước mặt Trình Thi Duyệt lần đầu tiên tỏ vẻ thiếu kiên nhẫn và thất vọng. Dù biểu cảm thoáng qua rất nhanh nhưng vẫn bị cô ta nhìn thấy. Kết quả đúng như Trình Thi Duyệt dự đoán, sau khi buổi tối ngại ngùng đó trôi qua, Tô Chấp Duật đã ngầm ra hiệu cho cô ta biết mối quan hệ giữa bọn họ đã kết thúc.

Tô Chấp Duật vốn dĩ cũng đã quên béng mất cô ta là ai, dù biết nhau đã được ba tháng nhưng hắn bận rộn với công việc nên số lần hai người gặp nhau cũng chỉ đếm trên đầu ngón tay.

Lúc này, đã một tháng trôi qua kể từ đêm hôm đó. Tô Chấp Duật cau mày nhìn hai cuộc gọi nhỡ và tin nhắn do đối phương gửi đến trên điện thoại, mất mấy giây mới nhớ được dáng vẻ của người phụ nữ này trong đầu. Nếu không có những dòng ghi chú trên điện thoại, hắn chắc đã quên luôn tên của cô ta rồi.

Nhà hàng mà Trình Thi Duyệt đã đặt bàn rất gần công ty, chỉ mất năm phút đi bộ qua một ngã tư.

Lúc 8 giờ 50 phút tối, Trình Thi Duyệt đang ngồi bên chiếc bàn gần cửa sổ trong nhà hàng, không khỏi ngạc nhiên khi nhìn thấy một bóng dáng quen thuộc đang đi qua đường. Cô ta không chắc hắn có chịu đến gặp hay không, nhìn thấy hắn đến sớm như thế khiến cô ta ngạc nhiên trong giây lát, sau đó vẻ mặt chuyển sang vô cùng vui sướng.

Tô Chấp Duật đẩy cửa nhà hàng ra, nhìn thấy Trình Thi Duyệt đang ngồi bỗng đứng dậy, trên mặt nở nụ cười nhiệt tình quen thuộc thay cho lời chào hỏi.

Điểm khác biệt duy nhất là hôm nay cô ta chuyển sang một phong cách mà hắn chưa từng thấy trước đây. Khuôn mặt trang điểm cực kỳ tao nhã, trang phục cũng giản dị và thoải mái khác hẳn với phong cách điệu đà lộng lẫy thường ngày, ngay cả đường uốn cong lông mi cũng phải đạt đến tiêu chuẩn nhất định.

Khi đến gần hơn, Tô Chấp Duật mới nhìn thấy còn một người khác đang ngồi cạnh cô ta.

“Ngài Tô! Mời ngồi.” Trình Thi Duyệt rất khách khí: “Cảm ơn ngài Tô bận trăm công nghìn việc bớt chút thời gian đến đây…” Vừa nói xong cô ta đã nhìn thấy Tô Chấp Duật nhìn liếc sang chỗ ngồi bên cạnh. Nụ cười trên môi vẫn không thay đổi, mở miệng nói: “Ngài Tô, đây là em họ của em, cuối tuần nó đến đây chơi với nên em đưa nó đi cùng.”

Dứt lời cô ta giơ tay chạm vào người em họ, “Còn không mau chào hỏi ngài Tô đi!”

Thiếu niên ngồi cạnh Trình Thi Duyệt cứ đưa mắt nhìn chằm chằm vào Tô Chấp Duật từ khi hắn xuất hiện.

Cậu có đôi mắt mèo tròn xoe, chiếc mũi thẳng, khuôn mặt trắng trẻo và con ngươi màu hổ phách. Một khuôn mặt kiều diễm, đôi môi đỏ mọng hơn nhiều so với người thường và còm có chút ướt át.

Lúc chưa bị Trình Thi Duyệt nhắc nhở, vẻ ngoài của cậu toát ra vẻ ngây ngô chưa trải sự đời giống một con nai con thỏ. Mãi đến khi nghe thấy cô ta thúc giục, cậu mới đột nhiên tỉnh táo lại. Cậu đứng dậy khỏi chỗ ngồi, đưa tay về phía Tô Chấp Duật và nói: “Xin chào ngài Tô, tôi tên là Phương Thời Ân.”

Tô Chấp Duật tùy ý liếc nhìn bàn tay đang đưa ra về phía mình, sau đó tầm mắt dời lên trên đánh giá, phát hiện ra ly rượu hoa quả sủi bọt có màu sắc sặc sỡ đã vơi đi phân nửa.

Dưới cái nhìn của Tô Chấp Duật, bàn tay đang đưa ra của Phương Thời Ân cứng đờ trong không trung, cậu phát hiện đối phương không có ý định bắt tay mình. Sau khi ánh mắt hai người thoáng đối diện với nhau vài giây, cậu lập tức quay sang nhìn Trình Thi Duyệt như đang cầu cứu.

Thiếu niên tên Phương Thời Ân hành động như một sản phẩm chưa được sản xuất hoàn chỉnh, đã bị Trình Thi Duyệt vội vàng đóng gói thật tinh xảo để đẩy đến đây.

Lúc này hắn mới thôi không nhìn nữa, chậm rãi đi tới ngồi xuống đối diện bọn họ, thản nhiên nói: “Tô Chấp Duật.”

Trình Thi Duyệt rốt cuộc cũng mỉm cười, nắm lấy tay Phương Thời Ân vỗ vỗ hai lần như đang trấn an, sau đó nói: “Ngồi xuống nói chuyện.”

Ba người cuối cùng cũng ngồi xuống, Trình Thi Duyệt gọi người phục vụ bảo dọn đồ ăn ra.

Ban đầu Tô Chấp Duật không muốn lãng phí quá nhiều thời gian trong cuộc gặp gỡ này. Lý do chính khiến hắn đến đây là để chia tay với Trình Thi Duyệt, sau đó thương lượng một cái giá để sau này khỏi bị làm phiền nữa.

Không ngờ cô ta lại đưa một đứa em họ đi cùng.

Ánh mắt thiếu niên thỉnh thoảng lại liếc nhìn hắn, dường như còn thấy cách nhìn này sẽ không bị ai phát hiện.

“Ngài Tô, chuyện lần trước thật sự là hiểu lầm, em không ngờ khóa cửa phòng đó lại bị hỏng. Nếu ngài thật sự không tin thì em có thể cho ngài số điện thoại của quản lý khách sạn, hắn sẽ làm chứng cho em… Chuyện xảy ra hôm đó hoàn toàn là sự cố, chứ không phải do em cố tình…”

Trình Thi Duyệt vừa thành thật giải thích vừa giới thiệu món ăn đã được dọn ra bàn: “Đây là món ăn mới ra trong tuần này. Ngài Tô thử xem mùi vị như thế nào…”

Trong suốt quá trình Tô Chấp Duật trông rất lơ đãng, hắn cầm chiếc nĩa cắt một miếng bít tết, nhưng còn chưa kịp bỏ vào trong miệng đã cảm thấy chân mình dưới bàn đang bị thứ gì đó cọ xát. Hắn tưởng mình bị ảo giác không ngờ lại bị cọ thêm lần thứ hai, đối phương dường như cũng không có ý định bỏ cuộc

Hắn cụp mắt xuống nhìn thấy một bàn chân đang kề sát mắt cá chân của mình từ từ cọ xát lên trên, đợi đến khi bàn chân cọ đến bắp chân bỗng nhiên bị hắn né tránh.

Tô Chấp Duật ngẩng đầu lên nhìn Phương Thời Ân, thấy cậu tự cho là tinh nghịch nháy mắt với mình một cái.

“Em trai của cô trông còn nhỏ quá.” Hắn nói một câu không đầu không đuôi.

Trình Thi Duyệt không để ý, trả lời: “Trông nó còn nhỏ nhưng năm nay cũng 21 tuổi rồi ạ.”

“À? Vậy không phải vẫn đang đi học sao? Chưa tốt nghiệp đại học phải không?”

“Dạ, nó học trễ hơn bạn cùng lứa một năm, hiện đang là sinh viên năm hai ở Đại học A.”

Trên khuôn mặt của hắn không thể nào đoán được được có bao nhiêu phần chân thành: “Đại học A à, điểm cũng cao đó.”

“Làm gì có, kém hơn ngài Tô nhiều… Khi nào có thời gian phải cho nó đi theo ngài Tô học tập…”

Trên mặt Trình Thi Duyệt hiện lên một nụ cười ngầm ẩn ý.

Không hiểu tại sao Tô Chấp Duật đột nhiên không muốn ăn nữa. Ngay lúc hắn đặt dao nĩa trên tay xuống, điện thoại cũng đúng lúc reo lên.

Bữa ăn tối kết thúc sau cuộc điện thoại, Tô Chấp Duật bị ba gọi về nhà cũ của gia đình. Sau khi hắn rời đi, Trình Thi Nguyệt muốn giảm cân để giữ dáng nên không ăn gì nữa, phần lớn đồ ăn đều rơi vào miệng của Phương Thời Ân.

Mười phút sau khi nhân vật chính Tô Chấp Duật rời đi, chị em họ cũng đi ra khỏi nhà hàng.

Xe của Trình Thi Duyệt là một chiếc Lamborghini màu vàng rất thời thượng, Phương Thời Ân ngồi lên xe rồi chiếc xe từ từ di chuyển ra khỏi gara dưới lòng đất. Khi chiếc xe thể thao hoà vào dòng xe cộ trên đường, cô ta ngẩng đầu vén những lọn tóc đang xõa xuống che khuất tầm nhìn ra sau tai, nói: “Thấy thế nào?”

Phương Thời Ân ngồi ở ghế phụ, nheo mắt nhớ lại khuôn mặt đó, cậu không khỏi ngồi thẳng dậy đến gần chị gái: “Chị ơi, không ngờ anh ấy lại đẹp trai như vậy.”

“Không đẹp thì chị dễ gì để lại cho em?” Trình Thi Duyệt nói, “Anh ta là con trai thứ hai của Tập đoàn Tô Thị, doanh nhân mới nổi chạm vào là bỏng tay ở Vân Thành. Với xuất thân, ngoại hình và học vấn như vậy, em biết có bao nhiêu người bon chen muốn tiếp cận anh ta không?”

Phương Thời Ân nghe vậy, trong giọng nói không khỏi cảm thấy có chút thiếu tự tin: “Vậy em có làm được không?”

Trong khi xe dừng lại chờ đèn đỏ, Trình Thi Duyệt vốn bị nghiện hút thuốc nên rút một điếu thuốc ngậm vào miệng, cậu lập tức lại gần lấy bật lửa châm cho cô ta.

Đốm đỏ trên tàn thuốc tắt, Trình Thi Duyệt nhả ra một hơi khói, nói: “Em sợ cái gì? Chẳng phải còn chị ở đây à?”

Phương Thời Ân nghe vậy mới bình tĩnh lại.

Lúc này thời gian đếm ngược đến đèn đỏ đã kết thúc, phía trước có rất nhiều xe cộ qua lại. Trình Thi Duyệt dập tắt điếu thuốc rồi lái xe đến một con đường cách xa trung tâm thành phố."""
    },
    {
        "id": "ln-c2",
        "chapterNumber": 2,
        "title": "Chương 2: Lời Mời Kết Bạn",
        "wordCount": 3100,
        "views": 138000,
        "publishedAt": "2025-01-11",
        "isExtra": False,
        "content": """Công bằng mà nói ở ấn tượng đầu tiên, người toát ra khí chất hoàn toàn khác biệt với những người khác như Tô Chấp Duật, lý lịch hoàn hảo và gia thế hiển hách, nhiều yếu tố cộng lại đều dễ khiến người ta cảm thấy thích hắn.

Trong số đó, Phương Thời Ân tuy không hiểu biết nhiều nhưng cũng có chút kiến ​​thức không nằm ngoài ngoại lệ.

Sau bữa ăn tối cậu đã lấy được thông tin liên lạc của Tô Chấp Duật từ chị gái của mình, sau khi gửi lời mời kết bạn cứ cách nửa giờ cậu lại nhấc điện thoại lên kiểm tra.

Trên đường trở về Trình Thi Duyệt không ngừng động viên cậu, còn không quên vẽ ra viễn cảnh tương lai đẹp đẽ. Lần đầu tiên tiếp xúc với Tô Chấp Duật, một người trong giới thượng lưu hoàn toàn khác biệt với thế giới của mình khiến cậu vừa phấn khích vừa lo lắng.

Mười hai giờ tối, Tô Chấp Duật cuối cùng cũng chấp nhận lời mời kết bạn của cậu.

Phương Thời Ân vui vẻ nhảy ra khỏi giường, thầm hò hét trong lòng “Á!”

Cùng lúc đó ở một nơi khác, sau khi Tô Chấp Duật báo cáo công việc ở nhà họ Tô xong, hắn lên xe nhìn thấy danh sách bạn bè trên điện thoại hiện lên một chấm đỏ.

Nhấp vào mới thấy hình đại diện của người đó là một con cừu thổi bong bóng, gửi yêu cầu kết bạn cho hắn.

“Xin chào, tôi là Phương Thời Ân.”

Việc ứng phó với Tô Nghiệp Đường ở nhà đã khiến hắn tốn không ít tâm sức. Sáng nay vừa đi công tác ở tỉnh khác về, cộng thêm việc liên tục họp hành ở công ty vào ban ngày, làm việc liên tục đến giờ này dù có mạnh khỏe đến đâu cũng không khỏi cảm thấy mệt mỏi.

Phương Thời Ân à, trong đầu nhớ lại thiếu niên xinh đẹp nhưng không được thông minh cho lắm mà mình đã gặp hôm nay, Trình Thi Duyệt đã giới thiệu đứa em họ của mình thế nào…

Trong lúc phân tâm, hắn chợt nhận ra tay phải cầm điện thoại đã vô tình bấm vào nút “chấp nhận”.

“Xin chào, tôi tên là Phương Thời Ân.”

Tin nhắn xuất hiện ở trên cùng, ngay khi hắn chấp nhận kết bạn đối phương đã nhanh chóng gửi tin nhắn.

Hình như đã đợi rất lâu rồi.

“Ngài Tô, trễ thế này còn chưa ngủ à? Công việc vất vả quá.”

Tô Chấp Duật xem tin nhắn cũng không trả lời.

Năm phút sau, Phương Thời Ân gửi tin nhắn thứ hai.

“Cho dù làm việc bận rộn cũng nhớ giữ gìn sức khỏe nha.”

Tô Chấp Duật bấm nút thoát ra, bấm vào ảnh đại diện của Phương Thời Ân rồi cài đặt chế độ nhắn tin không làm phiền.

Gay.

Hắn không biết có nên cảm thấy may mắn, vì Trình Thi Duyệt phán đoán hắn là gay chứ không phải bị bệnh liệt dương sau đêm đó không, nhưng hắn cũng không hoàn toàn đồng ý với kết luận này.

Khi còn học ở trong nước, hắn và anh trai Tô Chấp Thư học cùng trường. Mẹ của bọn họ Trần Bích Uyển xuất thân từ gia đình danh gia vọng tộc, nên việc giáo dục con cái vô cùng nghiêm khắc. Tô Chấp Dật phải duy trì thành tích xuất sắc mới có thể khiến cho nét mặt ít khi nở nụ cười của mẹ bớt đi phần lạnh lùng, ánh mắt bớt đi phần sắc bén khi nhìn mình.

Theo những gì mà lúc nhỏ hắn tình cờ nghe được từ người giúp việc đã đi theo Trần Bích Uyển hơn mười mấy năm, Tô Chấp Duật không phải là con ruột của Trần Bích Uyển mà là sản phẩm từ một đêm phong lưu của Tô Nghiệp Đường thời trẻ.

Trần Bích Uyển cũng không hề giấu giếm chuyện này.

Hắn không biết tên mẹ ruột của mình là gì, dù lúc còn nhỏ hay khi đã trưởng thành cũng chưa bao giờ có ý định tìm kiếm thông tin về người đó. Nhưng hắn cũng thông cảm cho những hành động phân biệt đối xử lén lún và đôi khi cũng quá trắng trợn của Trần Bích Uyển suốt mấy năm qua.

Sau khi học xong cấp 2, lên cấp 3 hắn theo học tại một trường tư thục quý tộc nổi tiếng ở nước ngoài, sau đó học lên đến chương trình nghiên cứu sinh mới trở về nước.

Lúc đại học hắn học ngành Khoa học máy tính, sau này lên nghiên cứu sinh lại chuyển sang ngành Tài chính, đồng thời cũng tham gia khá nhiều cuộc thi khác nhau để giành giải thưởng. Tất nhiên đây cũng không phải chuyện dễ dàng, hắn gần như dành toàn bộ thời gian và sức lực vào việc học. Còn phải luôn chú ý đến hành động của Tô Chấp Thư, mỗi lần ba mẹ cho anh trai mình những cơ hội gì thì hắn cũng phải trang thủ giành phần.

Giữa cuộc sống học tập bận rộn, hắn còn phải tìm thời gian gọi điện cho Tô Nghiệp Đường thể hiện “lòng hiếu thảo” đúng lúc, mong rằng ba sẽ không quên mất đứa con ngoài giá thú này.

Mặc dù bận bịu với việc học và tham gia các hoạt động ngoại khóa, Tô Chấp Dật sở hữu ngoại hình lẫn thành tích nổi bật nên cũng không ít người thích hắn. Lúc đó hắn cảm thấy bản thân khó tìm được thời gian rảnh để yêu đương, bởi vì duy trì một mối quan hệ cũng cần phải bỏ ra nhiều thời gian và công sức. Sau khi từ chối nhiều lời tỏ tình, khi còn học đại học cuối cùng hắn cũng gật đầu đồng ý hẹn hò với một cô gái gốc Á đã theo đuổi mình dai dẳng suốt nửa năm.

Nhưng mối tình này kết thúc chóng vánh chỉ sau một tháng.

Đối phương ngỏ lời chia tay trước.

Cô nói một người chỉ ngủ 5 tiếng mỗi ngày như Tô Chấp Duật, dành hết thời gian còn lại cho việc học tập, nghiên cứu và thi cử, đến bây giờ vẫn chưa đột ngột lăn ra chết đúng là một điều kỳ diệu. Lời chia tay mà cô dành cho hắn khá tế nhị, đó là chúc hắn sống lâu trăm tuổi.

Kể từ đó Tô Chấp Duật đã hoàn toàn từ bỏ ý định yêu đương.

Hắn cũng biết bản tính của mình lạnh nhạt trời sinh, không thể yêu ai càng không có ham muốn, nên hắn sẵn sàng tự mình giải quyết các vấn đề sinh lý vì bản thân là người vô tính.

Khi đưa ra nhận xét về bản thân, hắn cũng không biết đó có phải là cách xác định đúng hay chưa.

Đương nhiên về vấn đề này, Cố Tân – người tốt nghiệp cùng trường và là người duy nhất hắn xem là bạn đã từng thẳng thắn nói rằng: Kiểu người như Tô Chấp Duật chỉ giao lưu với những người cần thiết, khi giao lưu với những kẻ không phù hợp với khuôn khổ tiêu chuẩn của mình đều coi như lãng phí thời gian, hơn nữa tính tình còn kiên trì cố chấp nên đến hiện tại cũng chưa có quan hệ thân mật với ai được, cũng rất có khả năng hắn bị tự luyến quá mức.

Sau bao nhiêu năm tháng cẩn trọng tính toán và sắp xếp thời gian chính xác đến từng phút từng giây, cuối cùng Tô Chấp Duật cũng đuổi kịp anh trai của mình, tốt nghiệp cùng năm với Tô Chấp Thư lớn hơn mình hai tuổi rồi vào công ty làm việc.

Mặc dù ở một mức độ nào đó Tô Nghiệp Đường đã đối xử rất công bằng giữa đứa con cả và đứa con ngoài giá thú, nhưng hắn vẫn không nghĩ như vậy, hắn thấy năng lực của mình vượt xa Tô Chấp Thư mà xếp hai người ngang nhau đã là một sự bất công.

Hai năm qua sức khỏe của Tô Nghiệp Đường ngày càng sa sút, trong năm nay đã phải nhập viện hai lần để hồi phục sức khỏe. Hắn nghi ngờ dưới sự dụ dỗ của Trần Bích Uyển, ông sẽ để lại phần lớn cổ phần của mình cho Tô Chấp Thư trước khi nghỉ hưu.

Trở lại vấn đề gay.

Bản thân hắn cũng không có kỳ thị những người đó, nhưng nếu hắn thực sự là gay thì đúng là một rắc rối lớn. Với kiểu người truyền thống và cổ hủ như Tô Nghiệp Đường chắc chắn sẽ rất tức giận, thậm chí hắn có thể hoàn toàn mất đi sự ủng hộ của ba mình.

Nửa năm trước Tô Chấp Thư đã đính hôn với Mạnh Lâm, gia đình nhà gái có quan hệ rất tốt với nhà bọn họ. Hai người lớn lên cùng nhau, nên việc đính hôn cũng do một tay Trần Bích Uyển sắp xếp.

Nếu Tô Chấp Dật là người đồng tính, tin này lan ra ngoài sẽ khiến hắn không thể liên hôn với gia tộc nào nữa, hậu quả của việc này sẽ khiến hắn mất đi rất nhiều khả năng cạnh tranh trong cuộc chiến tranh giành gia sản với Tô Chấp Thư.

Thế hắn có phải gay hay không?

Khuôn mặt của thiếu niên tên Phương Thời Ân đêm nay lại hiện lên trong tâm trí hắn.

Hắn mở điện thoại ra đã thấy 12h30, đối phương chúc hắn ngủ ngon và bảo hắn đi ngủ sớm. Hắn tắt màn hình thở ra một hơi, tựa lưng vào ghế rồi từ từ cụp mắt xuống. Nếu có thể hắn vẫn hy vọng thà đừng như vậy thì tốt hơn.

“Hôm nay trời trở lạnh, anh nhớ mặc thêm quần áo nhé.”

“Anh Chấp Duật, sao anh không để ý đến em?”

Sau một tuần, Phương Thời Ân vẫn miệt mài gửi tin nhắn cho Tô Chấp Duật, thỉnh thoảng nhận được câu trả lời: “Ừ” hoặc “Đang bận” của hắn khiến cậu như được tiếp thêm động lực, lúc đầu còn gọi ngài Tô rất lịch sự dần biến thành anh Chấp Duật luôn rồi.

“Ối, hôm nay em vô tình va vào góc bàn, đau quá đi.”

Tin nhắn hôm nay lại gửi đến, sau khi nhắn xong lại gửi kèm một bức ảnh.

Dưới ánh đèn sáng rực trong bức ảnh, trên đầu gối vốn trắng nõn mịn màng xuất hiện một mảng bầm tím nhỏ do va đập, xung quanh phần da không bị thương có ánh hồng phớt nhẹ. Bức ảnh không chỉ chụp đầu gối mà còn cả một đoạn cẳng chân trắng mịn đang cuộn tròn trên chiếc ghế sofa tối màu.

Khi Tô Chấp Duật xem được tin nhắn này, đối phương đã gửi từ hai giờ trước.

Ánh mắt hắn dừng lại ở bức ảnh vài giây, không hiểu vì sao lại có cảm giác nếu cứ tiếp tục như vậy cậu sớm muộn gì cũng gửi ảnh khỏa thân cho mình."""
    }
]

with open("part1.json", "w", encoding="utf-8") as f:
    json.dump(part1, f, ensure_ascii=False, indent=2)

print("Part 1 built with", len(part1), "chapters")
